#!/bin/sh

java -cp dist.lib.* -jar dist/RegiaPNPlayer.jar
